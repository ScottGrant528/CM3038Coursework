package SliTilPuzzle;

import aips.search.Node;
import aips.search.State;
import aips.search.informed.BestFirstSearchProblem;
 

public class SliTilProblem extends BestFirstSearchProblem {

	public SliTilProblem(State initalState, State goalState) {
		super(initalState, goalState);
	};
	
	@Override
	public double evaluation(Node node) {
		return heuristic(node.state);
	};

	@Override
	public boolean isGoal(State state) {
		// TODO Auto-generated method stub
		return false;
	};
	
	public double heuristic (State currentState) {
		
		return this.misplacedTiles(currentState);
	};
	
	//To count the number of misplaced tiles
	public double misplacedTiles(State currentState) {
		double result = 0.0; //initialised value is 0.0 
		
		String[] tiles = ((SliTilState)currentState).tiles; //create a 1D array to store the current state 
		String[] goalTiles = ((SliTilState)this.goalState).tiles; //create a 1D array to store the goal state
		
		//for loop to iterate through the arrays and decide if the two arrays are equal
		for(int i = 0; i < tiles.length; i++) {
			if(tiles[i] != goalTiles[i]) { //equality check
				result++; //if not, the misplaced tiles counter will add one
			};
		};
		return result; //returning the count of the misplaced tiles
	};
	
}
