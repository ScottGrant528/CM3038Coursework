package SliTilPuzzle;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import aips.search.ActionStatePair;
import aips.search.State;

/*
 * TO DO LIST: 
 * 
 * 	Attributes [X]
 * 	toString [X]
 * 	equals [X]
 * 	constructor [X]
 * 	successor [ ]
 * 	hashCode/hash (optional) [X]  
 * 
 */

public class SliTilState implements State{

	

	/*
	 * Board information:
	 * 	of size: 4
	 * 	tiles: 
	 * 		1 of each 'R,G,B'
	 * 		2 of empty space '-'
	 */
	
	// Store the game state tiles in a 1D array
	public String tiles[];
	
	//Constructor creating a board of just blank spaces
	public SliTilState() {
		this.tiles = new String[4]; //Create a board of size 4
		for(int i = 0; i < tiles.length; i++) { //Selecting each tile on the board
			tiles[i] += "-"; //Populating the board with empty spaces
		};
	}

	//Populating the board, given an initial state 
	public SliTilState(String[] initialState) {
		this.tiles = new String[4]; //Create a board of size 4
		for(int i = 0; i < tiles.length; i++) { //Selecting each tile on the board
			tiles[i] = initialState[i]; //Populating the board from the initial state board
		};
	};
	
	//Returning the board as a string for output
	public String toString() {
		String result = "";
		
		for(int i = 0; i < tiles.length; i++) { //Selecting each tile on the board
			result += tiles[i];
		};
		
		return result;
	}

	//Tests the equality of two boards
	public boolean equals(Object state) {
		if(!(state instanceof SliTilState)) {
			return false;
		};
		SliTilState sliTilState = (SliTilState)state; //cast param into SliTilState for easier manipulation
		for(int i = 0; i < tiles.length; i++) {
			if(this.tiles[i] != sliTilState.tiles[i]) { //if there is a difference in the two boards, it will fail the check
				return false;
			};
		};
		return true; // only reaches this if all elements are equal
	};
	
	
	public SliTilState applyAction(SliTilAction action) {
		SliTilState nextState = new SliTilState(this.tiles); //create the next state as a copy of the current state
		
		nextState.tiles[action.blankSpace] = action.tileToSlide;
		nextState.tiles[action.tileIndex] = "-";
		return nextState;
	}
	
	@Override
	public List<ActionStatePair> successor() {
		List<ActionStatePair> result=new ArrayList<ActionStatePair>();
		
		
		//Find the index of the blank space in the current state
		int blankSpace = 0; 
		for(blankSpace = 0; blankSpace < tiles.length; blankSpace++) {
			if(this.tiles[blankSpace] == "-") {
				break;
			}
		}
		
		if(blankSpace == 0) {
			
		}
		
		
		switch(this.tiles) {
		
		case "R":
			
			break;
		case "G":
			
			break;
		case "B":
		
			break;
		}
		
		
		return null;
	};
	
	
	//Eclipse Auto-Generated Hashcode method
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(tiles);
		return result;
	}
	
	
	
			
};
