package SliTilPuzzle;

import aips.search.Action;



public class SliTilAction extends Action {
	public int blankSpace; //index of the blank space
	public String tileToSlide; //the tile to slide
	public int tileIndex; //index of tile to slide
	
	//Create a SliTilAction object
	public SliTilAction(int blankSpace, String tileToSlide, int tileIndex) {
		this.blankSpace = blankSpace;
		this.tileToSlide = tileToSlide;
		this.tileIndex = tileIndex;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		
		return "Slide tile: " + tileToSlide;
	};

	
	
	
};
