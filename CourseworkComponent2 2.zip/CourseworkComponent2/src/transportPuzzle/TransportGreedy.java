package transportPuzzle;

import aips.search.informed.*;
import aips.search.*;



public abstract class TransportGreedy extends BestFirstSearchProblem{

	/**
	 * Construct a Sq8Problem object from the initial and goal state.
	 * @param initialState	The initial state.
	 * @param goalState		The goal state.
	 */
	public TransportGreedy(State initalState, State goalState) {
		super(initalState, goalState);
		
	} //End of method

	/**
	 * The evaluation function required by an informed search.
	 * @param node	The node to be evaluated.
	 * @return The score of the node. The lower the score, the more promising the node.
	 */
	@Override
	public double evaluation(Node node) {
		// TODO Auto-generated method stub
		return heuristic(node.state);
	}
	
	public abstract double heuristic(State currentState);

	
	/**
	 * This isGoal testing method defines that the a state must be
	 * equal to the goal state (as an attribute in the problem object)
	 * to be a goal.
	 */
	@Override
	public boolean isGoal(State state) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
