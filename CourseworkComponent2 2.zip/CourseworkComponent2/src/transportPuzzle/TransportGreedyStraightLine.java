package transportPuzzle;

import aips.search.State;

public class TransportGreedyStraightLine extends TransportGreedy{

	public TransportGreedyStraightLine(State initalState, State goalState) {
		super(initalState, goalState);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double heuristic(State currentState) {
		// TODO Auto-generated method stub
		return 0;
	}

}
