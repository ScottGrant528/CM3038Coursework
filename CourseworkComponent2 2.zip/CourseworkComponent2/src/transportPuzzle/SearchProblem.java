package transportPuzzle;

import aips.search.State;
import aips.search.informed.BestFirstSearchProblem;

public abstract class SearchProblem extends BestFirstSearchProblem{

	public SearchProblem(State start, State goal) {
		super(start, goal);
		// TODO Auto-generated constructor stub
	}//End of Method
	
	

}//End of Class
