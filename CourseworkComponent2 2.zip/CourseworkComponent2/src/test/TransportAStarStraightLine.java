package test;

public class TransportAStarStraightLine {
}
