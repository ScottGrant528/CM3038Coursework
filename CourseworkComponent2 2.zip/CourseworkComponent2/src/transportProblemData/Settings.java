package transportProblemData;

/**
 * Settings class to store the costs of movement between cities
 * @author scottgrant
 *
 */
public class Settings {
	
		//Fixed costs for travelling between cities
		private final double costAB = 80.0;
		private final double costBC = 20.0;
		private final double costCA = 50.0;
		
		//variable cost are
		private final double costABperTon = 1.0;
		private final double costBCperTon = 4.0;
		private final double costCAperTon = 2.0;
		
		//Max cargo weight
		private final double maxLoad = 15.0; 
		
		/*
		 * Getter methods
		 */
		public double getCostAB() {
			return costAB;
		}//End of Method

		public double getCostBC() {
			return costBC;
		}//End of Method

		public double getCostCA() {
			return costCA;
		}//End of Method

		public double getCostABperTon() {
			return costABperTon;
		}//End of Method

		public double getCostBCperTon() {
			return costBCperTon;
		}//End of Method

		public double getCostCAperTon() {
			return costCAperTon;
		}//End of Method

		public double getMaxLoad() {
			return maxLoad;
		}//End of Method

		//Returns the class as a string
		public String toString() {
			String result = "===Settings===\n";
			result += "Truck max: " + maxLoad + "\n";
			result += "Fixed cost: A->B: " + costAB + " B->C: " + costBC + " C->A: " + costCA + "\n";
			result += "Cost per ton: A->B: " + costABperTon + " B->C: " + costBCperTon + " C->A: " + costCAperTon;
			
			return result;
		}//End of Method
}//End of Class
