package transportProblemData;

public enum CargoName {
	C1,C2,C3,C4,C5,C6 //enum types for the cargo names
}//End of Class
