package transportProblemData;
/**
 * Class to define names for the travel between cities
 * @author scottgrant
 *
 */
public enum CityTravel {
	AB,BC,CA //enun for the city travel
}//End of method
