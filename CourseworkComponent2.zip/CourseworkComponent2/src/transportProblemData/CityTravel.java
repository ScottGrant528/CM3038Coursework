package transportProblemData;

public enum CityTravel {
	AB,BC,CA
}
