package transportProblemData;
/**
 * A class to store the city names
 * @author scottgrant
 *
 */
public enum CityName {
	A,B,C //enums of the city names
}//End of Class
