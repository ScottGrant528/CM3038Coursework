package transportProblemData;
//A class to list the cargo names
public enum CityName {
	A,B,C
}
