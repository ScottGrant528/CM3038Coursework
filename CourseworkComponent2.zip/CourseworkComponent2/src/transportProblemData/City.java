package transportProblemData;

import java.util.ArrayList;

public class City {
	
	//City name using an enum class
	private CityName name;
	
	//What cargo's are stored in the city
	private ArrayList <Cargo> cityCargo = new ArrayList<Cargo>();
	
	//Fixed costs for travelling between cities
	private final double costAB = 80.0;
	private final double costBC = 20.0;
	private final double costCA = 50.0;
	
	//variable cost are
	private final double costABperTon = 1.0;
	private final double costBCperTon = 4.0;
	private final double costCAperTon = 2.0;
	
	//Is the truck in this city
	private boolean occupied = false;
	
	//Constructor
	public City(CityName name, boolean occupied) {
		super();
		this.name = name;
		this.occupied = occupied;
	}
	
	//Getters and Setters
	public CityName getName() {
		return name;
	}

	public void setName(CityName name) {
		this.name = name;
	}

	public ArrayList<Cargo> getCityCargo() {
		return cityCargo;
	}

	public void addToCityCargo(Cargo cargo) {
		this.cityCargo.add(cargo);
	}
	
	public void removeFromCityCargp(Cargo cargo) {
		this.cityCargo.remove(cargo);
	}
	
	
	public boolean isOccupied() {
		return occupied;
	}

	public void setOccupied(boolean occupied) {
		this.occupied = occupied;
	}

	public double getCostAB() {
		return costAB;
	}

	public double getCostBC() {
		return costBC;
	}

	public double getCostCA() {
		return costCA;
	}

	public double getCostABperTon() {
		return costABperTon;
	}

	public double getCostBCperTon() {
		return costBCperTon;
	}

	public double getCostCAperTon() {
		return costCAperTon;
	}
	
	//toString method
	@Override
	public String toString() {
		return "City [name=" + name + ", cityCargo=" + cityCargo.toString() + ", costAB=" + costAB + ", costBC=" + costBC
				+ ", costCA=" + costCA + ", costABperTon=" + costABperTon + ", costBCperTon=" + costBCperTon
				+ ", costCAperTon=" + costCAperTon + ", occupied=" + occupied + "]";
	}
	
	
	
	
	
}
