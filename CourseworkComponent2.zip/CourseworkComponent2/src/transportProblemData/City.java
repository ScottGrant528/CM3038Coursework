package transportProblemData;

import java.util.ArrayList;
import java.util.Objects;

/**
 * This class models a city
 * @author scottgrant
 *
 */
public class City {
	
	//City name using an enum class
	private CityName name;
	
	//What cargo's are stored in the city
	private ArrayList <Cargo> cityCargo = new ArrayList<Cargo>();
	
	//Is the truck in this city
	private boolean occupied = false;
	
	//Constructor
	public City(CityName name, boolean occupied) {
		super();
		this.name = name;
		this.occupied = occupied;
	}//End of Method
	
	//Getters and Setters
	public CityName getName() {
		return name;
	}//End of Method

	public void setName(CityName name) {
		this.name = name;
	}//End of Method

	public ArrayList<Cargo> getCityCargo() {
		return cityCargo;
	}//End of Method

	public void addToCityCargo(Cargo cargo) {
		this.cityCargo.add(cargo);
	}//End of Method
	
	public void removeFromCityCargp(Cargo cargo) {
		this.cityCargo.remove(cargo);
	}//End of Method
	
	//Converts the city cargo array to a string
	public String getCityCargoToString() {
		String result = "";
		//iterates through the array 
		for(int i = 0; i < cityCargo.size(); i++) {
			result += cityCargo.get(i).toString();
			//if the item is not the last item, add a space at the end
			//this spaces the output, increasing readability
			if(i < cityCargo.size() - 1) {
				result += " ";
			}//End of if statement
		}//End of For loop
		return result;
	}//End of Method
	
	//Returns occupation state
	public boolean isOccupied() {
		return occupied;
	}//End of Method

	public void setOccupied(boolean occupied) {
		this.occupied = occupied;
	}//End of Method
	
	//Returns the city as a string
	@Override
	public String toString() {
		return "City [name=" + name + ", cityCargo=" + cityCargo.toString() + ", occupied=" + occupied + "]";
	}//End of Method
	
	//Converts the city class into a hash(int)
	@Override
	public int hashCode() {
		return Objects.hash(cityCargo, name, occupied);
	}//End of Method

	//Checks equality of two city objects
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof City))
			return false;
		City other = (City) obj;
		return Objects.equals(cityCargo, other.cityCargo) && name == other.name && occupied == other.occupied;
	}//End of Method
}//End of Class
