package transportProblemData;
//A class to contain the data about a certain cargo
public class Cargo {
	//Fields to store the data about the cargo
	private CargoName name; 
	private double weight;
	
	
	//Constructor
	public Cargo(CargoName name, double weight) {
		super();
		this.name = name;
		this.weight = weight;
	}
	//getter and setter methods
	public CargoName getName() {
		return name;
	}
	
	public void setName(CargoName name) {
		this.name = name;
	}
	
	public double getWeight() {
		return weight;
	}
	
	public void setWeight(double weight) {
		this.weight = weight;
	}
	//toString method
	@Override
	public String toString() {
		return "Cargo [name=" + name + ", weight=" + weight + "t]";
	}
	
	
}
