package transportProblemData;

//A class to contain the data about a certain cargo
public class Cargo {
	
	//Fields to store the data about the cargo
	private CargoName name; 
	private double weight;
	
	
	//Constructor
	public Cargo(CargoName name, double weight) {
		super();
		this.name = name;
		this.weight = weight;
	}//End of Method
	//getter and setter methods
	public CargoName getName() {
		return name;
	}//End of Method
	
	public void setName(CargoName name) {
		this.name = name;
	}//End of Method
	
	public double getWeight() {
		return weight;
	}//End of Method
	
	public void setWeight(double weight) {
		this.weight = weight;
	}//End of Method
	
	//toString method
	@Override
	public String toString() {
		return name + " (" + weight + ")";
	}//End of Method
}//End of Class