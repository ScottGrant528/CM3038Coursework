package transportProblemData;

import java.util.ArrayList;

public class Truck {

	//Setting the maximum truck cargo limit
	private final double maxLoad = 15.0; //max cargo weight of 15 tonnes
	//Storing the city that the truck is in 
	private CityName currentCity;
	//Arraylist to store the truck's cargo
	private ArrayList <Cargo> truckCargo = new ArrayList<Cargo>();
	
	//Constructor
	public Truck(CityName currentCity) {
		super();
		this.currentCity = currentCity;
	}
	//empty constructor
	public Truck() {
		super();
		this.currentCity = null;
	}
	
	//getters and setters
	public CityName getCurrentCity() {
		return currentCity;
	}

	public void setCurrentCity(CityName currentCity) {
		this.currentCity = currentCity;
	}

	public ArrayList<Cargo> getTruckCargo() {
		return truckCargo;
	}

	public void setTruckCargo(ArrayList<Cargo> truckCargo) {
		this.truckCargo = truckCargo;
	}

	public double getMaxLoad() {
		return maxLoad;
	}
	
	//toString Method
	@Override
	public String toString() {
		return "Truck [maxLoad=" + maxLoad + ", currentCity=" + currentCity + ", truckCargo=" + truckCargo + "]";
	}
	
	
	
	
	
}
