package transportProblemData;

import java.util.ArrayList;
import java.util.Objects;


/**
 * Class to model the truck
 * @author scottgrant
 *
 */
public class Truck {
	
	//Storing the city that the truck is in 
	private CityName currentCity;
	//Arraylist to store the truck's cargo
	private ArrayList <Cargo> truckCargo = new ArrayList<Cargo>();
	
	/*
	 * Constructor
	 */
	public Truck(CityName currentCity) {
		super();
		this.currentCity = currentCity;
	}//End of Method
	//empty constructor
	public Truck() {
		super();
		this.currentCity = null;
	}//End of Method
	
	/*
	 * Getter and Setter Methods
	 */
	public CityName getCurrentCity() {
		return currentCity;
	}//End of Method

	public void setCurrentCity(CityName currentCity) {
		this.currentCity = currentCity;
	}//End of Method

	public ArrayList<Cargo> getTruckCargo() {
		return truckCargo;
	}//End of Method
	
	//Calculates the total weight of the truck
	public double getTruckCargoWeight() {
		double truckWeight = 0;
		for(int i = 0; i < truckCargo.size(); i++) {
			truckWeight += truckCargo.get(i).getWeight();
		}
		return truckWeight;
	}//End of Method

	public void setTruckCargo(ArrayList<Cargo> truckCargo) {
		this.truckCargo = truckCargo;
	}//End of Method
	
	/*
	 * toString method returns class as a string
	 */
	@Override
	public String toString() {
		return "Truck [currentCity=" + currentCity + ", truckCargo=" + truckCargo + "]";
	}//End of Method
	
	//Converts the class into a hashcode (int)
	@Override
	public int hashCode() {
		return Objects.hash(currentCity, truckCargo);
	}//End of Method
	
	//Checks the equality of two hashcode objects
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Truck))
			return false;
		Truck other = (Truck) obj;
		return currentCity == other.currentCity && Objects.equals(truckCargo, other.truckCargo);
	}//End of method
}//End of Class