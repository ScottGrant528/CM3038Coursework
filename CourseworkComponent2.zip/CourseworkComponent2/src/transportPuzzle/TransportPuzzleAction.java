package transportPuzzle;

import aips.search.Action;
import transportProblemData.*;


public class TransportPuzzleAction extends Action {
	
	public int cargoCityCurrent, cargoCityNext; //Current and next cites
	public Cargo cargoToMove; //the piece of cargo that will be moved
	public Truck truck; //the current truck
	
	/**
	 *  Create a TransportPuzzleAction object.
	 *  
	 * 	@param cargoCityCurrent		The current city of the cargo
	 * 	@param cargoCityNext		The next city of the cargo
	 * 	@param cargoToMove			The cargo that will be moved
	 */
	public TransportPuzzleAction(int cargoCityCurrent, int cargoCityNext, Cargo cargoToMove) {
		this.cargoCityCurrent = cargoCityCurrent;
		this.cargoCityNext = cargoCityNext;
		this.cargoToMove = cargoToMove;
	}//end method
	
	@Override
	public String toString() {
		return "Move Cargo: " + cargoToMove.toString();
	}//end method
	
	//Returns the cargo to be moved and where it is moving from and to
	public String toStringFull() {
		//Strings to hold the city names
		String cityCurr, cityNext; 
		//Converts from int to city name
		switch(cargoCityCurrent) {
		case 0:
			cityCurr = "City A"; break;
		case 1: 
			cityCurr = "City B"; break;
		case 2:
			cityCurr = "City C"; break;
		default:
			cityCurr = "Unrecognized City";
		}//End of switch
		
		//Converts from int to city name
		switch(cargoCityNext) {
		case 0:
			cityNext = "City A"; break;
		case 1: 
			cityNext = "City B"; break;
		case 2:
			cityNext = "City C"; break;
		default:
			cityNext = "Unrecognized City";
		}//End of switch
		
		return "Cargo " + cargoToMove.toString()+ " to be moved from: " + 
				cityCurr + " -> " + cityNext;
	}//End Method
}//end class