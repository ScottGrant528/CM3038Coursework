package transportPuzzle;
import java.util.*;
import aips.search.*;
import transportProblemData.*;

/**
 * This class models the state of the TransportPuzzle problem
 * @author Scott Grant
 *
 */
public class TransportPuzzleState implements State {

	public City map[]; //map array to hold the three cities
	public final int mapSize = 3; //size of array to control problem size
	Truck truck = new Truck(); //Creating the truck object
	
	Settings settings = new Settings();
	
	/**
	 * Creates an empty state object
	 */
	public TransportPuzzleState() {
		this.map = new City[mapSize];
		//Iterates through the map array
		for(int i = 0; i < mapSize; i++) {
			switch(i){
				case 0: this.map[i] = new City(CityName.A, true); break;
				case 1: this.map[i] = new City(CityName.B, false);; break;
				case 2: this.map[i] = new City(CityName.C, false);; break;
				default: System.out.println("Map Size error");
			} //End of Switch statement
		} //End of For loop
	}//End of Method	
	
	
	/**
	 * Given the 3 city classes, create a TransportPuzzleState object
	 * @param A - City A
	 * @param B - City B
	 * @param C - City C
	 */
	public TransportPuzzleState(City A, City B, City C, Truck T) {
		this.map = new City[mapSize];
		/**
		 * Iterates through the map array.
		 * Setting the cities to their respective places in the array.
		 * Checks to see if the truck is at any of the cities.
		 * If so it add's the city name to the truck variable current city.
		 */
		for(int i = 0; i < mapSize; i++) {
			//Switch statement for each case of the array
			switch(i){
				case 0: this.map[i] = A; //Set index 0 of the array to A
						if(A.isOccupied() == true) //If A is occupied set truck to be there
						{
							T.setCurrentCity(A.getName()); 
						} break;
						
				case 1: this.map[i] = B; //Set index 1 of the array to B 
						if(B.isOccupied() == true) //If B is occupied set truck to be there
						{
							T.setCurrentCity(B.getName()); 
						} break;
						
				case 2: this.map[i] = C;  //Set index 2 of the array to C
						if(C.isOccupied() == true) //If C is occupied set truck to be there
						{
							T.setCurrentCity(C.getName()); 
						} break;
						
				default: System.out.println("Map Size error");
			}//End of Switch statement
		}//End of For loop
	}//End of Method
	
	/*
	 * toString method
	 * converts the state class and the arrays it contains 
	 * into a printable string
	 */
	public String toString() {
		String result = "";
		
		/**
		 * Iterates through the map array.
		 * Switch statement for each element of the array.
		 * Appends the City name.
		 * For each element it checks to see if the truck is there, adding it to the string if so. 
		 * It then appends Cargo class's toString method for each of the cargos in the city.  
		 */
		for(int i = 0; i < this.mapSize; i++) {
			switch(i){
				case 0: result += "A: " + addTruck(this.map[i].isOccupied(), i) + 
							this.map[i].getCityCargoToString() + "\n";
						break;
						
				case 1: result += "B: " + addTruck(this.map[i].isOccupied(), i) + 
						this.map[i].getCityCargoToString() + "\n";
						break;
				case 2: result += "C: " + addTruck(this.map[i].isOccupied(), i) + 
						this.map[i].getCityCargoToString() + "\n";
					break;
			};//End of Switch Statement
		};//End of For loop
		return result; //returning the string
	}//End of Method
	
	/**
	 * Checks to see if the truck is at a city for the toString method, and if so will return a string
	 * @param occupied
	 * @return
	 */
	private String addTruck(boolean occupied, int i) {
		if(this.map[i].isOccupied() == true){
			return "TRUCK ";
		}//End of if statement
		return "";
	}//End of Method
	
	/**
	 * 
	 * This method checks the equality of two TransportPuzzleState objects 
	 * @param state The object that the equality will be compared with
	 */
	public boolean equals(Object state) {
		if(!(state instanceof TransportPuzzleState)) {
			return false;
		}//End of if statement
		
		// cast param into Transport puzzle state for easier manipulation
		TransportPuzzleState transState = (TransportPuzzleState) state; 
		int counter = 0; //counter to ensure all 3 cities are equal
		//Iterating through the map size
		for(int i = 0; i < mapSize; i++) {
			//if the given city's citycargo arraylist is equal to the other citycargo arraylist
			if(transState.map[i].getCityCargo().equals(this.map[i].getCityCargo())){	
				counter++; // add one to the counter
			}//End of if statement
		}//End of F0r loop
		//If all three city checks successfully went through
		if(counter == 3) {
			return true;
		} else {
			return false;
		}
	}//End of Method
	
	/**
	 * The hash code method returns a hash (int value) of the state object
	 * Using a generated hashcode method from eclipse
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(map);
		result = prime * result + Objects.hash(mapSize, truck);
		return result;
	}//End of Method
	
	/**
	 * 
	 * Successor method to generate the possible nodes from the current node
	 */
	@Override
	public List<ActionStatePair> successor(){
		//Creating the action state pair arraylist
		List<ActionStatePair> result = new ArrayList<ActionStatePair>();
		
		//Int to store location of nexy city
		int nextCity;
		//Setting the cityname enums to variable for ease of use 
		CityName A = CityName.A;
		CityName B = CityName.B;
		CityName C = CityName.C;
		
		/**
		 * 
		 * Step one -> Find the truck's location
		 * 
		 */
		//Initalising truck location to number not on map
		int truckCityLocation = 3;
		//For loop to iterate through city map array and find the truck's location
		for(int i = 0; i < this.mapSize; i++) {
			if(this.map[i].isOccupied()) {
				//System.out.println("Truck is at location -> " + i);
				truckCityLocation = i;
			} else {
				//System.out.println("TRUCK HAS NO LOCATION");
				//truckCityLocation = -1;
			}
		}
		
		/**
		 * 
		 * Step two -> Find the possible cities that the truck could travel to
		 * 
		 */
		//Store the cities that the truck can travel to
		ArrayList <CityName> possibleCities = new ArrayList<>();
		
		if(truckCityLocation == 0) { //If truck is at City A
			//Empty arraylist
			possibleCities.clear();
			//Add the cities that can be traveled to
			possibleCities.add(B);
			possibleCities.add(C);
		} else if (truckCityLocation == 1) { //If truck is at City B
			//Empty arraylist
			possibleCities.clear();
			//Add the cities that can be traveled to
			possibleCities.add(A);
			possibleCities.add(C);
		} else if (truckCityLocation == 2) { //If truck is at City C
			//Empty arraylist
			possibleCities.clear();
			//Add the cities that can be traveled to
			possibleCities.add(A);
			possibleCities.add(B);
		}
		//System.out.println("Possible Cities -> " + possibleCities.toString());
		//System.out.println("Truck location: " + truckCityLocation);
		/**
		 * Step three -> Create ActionStatePairs for each 
		 * 
		 * 
		 */
		for(int i = 0; i < possibleCities.size(); i++) {
			//System.out.println("Entered For Loop");
			if(possibleCities.get(i).equals(A)) {
				//System.out.println("Entered if statement");
				
				//Set the next city to A 
				nextCity = 0;
				
				//Add an action for moving each cargo object
				for (int j = 0;this.map[truckCityLocation].getCityCargo().size() > j; j++) { 
					//System.out.println("in for loop");
					TransportPuzzleAction action = new TransportPuzzleAction(truckCityLocation, nextCity, this.map[truckCityLocation].getCityCargo().get(j));
					//System.out.println("ACTION:" + action.toStringFull());
					TransportPuzzleState nextState = this.applyAction(action);
					//System.out.println("CURRENT STATE: \n" + this.toString());
					//System.out.println("NEXT STATE: \n" + nextState.toString());
					ActionStatePair actionStatePair = new ActionStatePair(action, nextState);
					//System.out.println("Action state pair: " + actionStatePair.toString());
					result.add(actionStatePair);
				} 
			} else if (possibleCities.get(i).equals(B)) {
				//System.out.println("Entered first else if statement");
				
				//Set the next city to B 
				nextCity = 1;
				//System.out.println(this.map[truckCityLocation].getCityCargo().size()); // outputs 2 so is working
				//Add an action for moving each cargo object
				for (int j = 0;this.map[truckCityLocation].getCityCargo().size() > j; j++){
					//System.out.println("Entered for in else if statement");
					TransportPuzzleAction action = new TransportPuzzleAction(truckCityLocation, nextCity, this.map[truckCityLocation].getCityCargo().get(j));
					TransportPuzzleState nextState = this.applyAction(action);
					ActionStatePair actionStatePair = new ActionStatePair(action, nextState);
					result.add(actionStatePair);
				}//End of For loop
			} else if (possibleCities.get(i).equals(C)) {
				//Set the next city to C 
				nextCity = 2;

				//Add an action for moving each cargo object
				for (int j = 0;this.map[truckCityLocation].getCityCargo().size() > j; j++) {
					TransportPuzzleAction action = new TransportPuzzleAction(truckCityLocation, nextCity, this.map[truckCityLocation].getCityCargo().get(j));
					TransportPuzzleState nextState = this.applyAction(action);
					ActionStatePair actionStatePair = new ActionStatePair(action, nextState);
					result.add(actionStatePair);
				}//End of For loop
			} else {
				System.out.println("Possible city equality failed");
			} //End of if loop
		}//End of For loop
		//returning the arraylist of all the actionstatepairs
		//System.out.println("Action State pair: ");
		return result; 
	}//End of Method

	/**
	 * Apply an action to the current state
	 * 
	 * @param action
	 * @return
	 */
	public TransportPuzzleState applyAction(TransportPuzzleAction action) {
		TransportPuzzleState nextState = this;
		//Adding the cargo to the new state
		nextState.map[action.cargoCityNext].addToCityCargo(action.cargoToMove);
		//System.out.println("action city cargo next " + action.cargoCityNext);
		//Adding truck from to new city
		nextState.map[action.cargoCityNext].setOccupied(true);
		//System.out.println("occupationg next city " + action.cargoCityNext);
		//Removing the cargo from the old state
		nextState.map[action.cargoCityCurrent].removeFromCityCargp(action.cargoToMove);
		//Adding truck from to new city
		nextState.map[action.cargoCityCurrent].setOccupied(false);
		//Return the state back
		return nextState;
	}//End of Method
}//End of Class
