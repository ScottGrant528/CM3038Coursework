package transportPuzzle;
import java.util.List;

import aips.search.*;
import transportProblemData.City;
import transportProblemData.CityName;
import transportProblemData.Truck;

/**
 * This class models the state of the TransportPuzzle problem
 * @author Scott Grant
 *
 */

public class TransportPuzzleState implements State {

	public City map[]; //map array to hold the three cities
	private final int mapSize = 3; //size of array to control problem size
	Truck truck = new Truck();
	
	/**
	 * Creates an empty state object
	 */
	public TransportPuzzleState() {
		this.map = new City[mapSize];
		//Iterates through the map array
		for(int i = 0; i < mapSize; i++) {
			switch(i){
				case 0: this.map[i] = new City(CityName.A, true); break;
				case 1: this.map[i] = new City(CityName.B, false);; break;
				case 2: this.map[i] = new City(CityName.C, false);; break;
				default: System.out.println("Map Size error");
			}
		}
	}	
		
	
	/**
	 * Given the 3 city classes, create a TransportPuzzleState object
	 * @param A - City A
	 * @param B - City B
	 * @param C - City C
	 */
	public TransportPuzzleState(City A, City B, City C, Truck T) {
		this.map = new City[mapSize];
		/**
		 * Iterates through the map array.
		 * Setting the cities to their respective places in the array.
		 * Checks to see if the truck is at any of the cities.
		 * If so it add's the city name to the truck variable current city.
		 */
		for(int i = 0; i < mapSize; i++) {
			//Switch statement for each case of the array
			switch(i){
				case 0: this.map[i] = A; //Set index 0 of the array to A
						if(A.isOccupied() == true) //If A is occupied set truck to be there
						{
							T.setCurrentCity(A.getName()); 
						} break;
						
				case 1: this.map[i] = B; //Set index 1 of the array to B 
						if(B.isOccupied() == true) //If B is occupied set truck to be there
						{
							T.setCurrentCity(B.getName()); 
						} break;
						
				case 2: this.map[i] = C;  //Set index 2 of the array to C
						if(C.isOccupied() == true) //If C is occupied set truck to be there
						{
							T.setCurrentCity(C.getName()); 
						} break;
						
				default: System.out.println("Map Size error");
			}
		}
		
	}
	
	public String toString() {
		String result = "";
		
		//Iterates though the map
		for(int i = 0; i < this.mapSize; i++) {
			//Switch statement for each case of the array
			//For each case it checks to see if the truck is there, adding it to the string if so
			/*
			 * Switch statement for each element of the array.
			 * Appends the City name.
			 * For each element it checks to see if the truck is there, adding it to the string if so. 
			 * It then appends Cargo class's toString method for each of the cargos in the city.  
			 */
			switch(i){
				case 0: result += "A: " + addTruck(this.map[i].isOccupied(), i) + 
							this.map[i].getCityCargo().toString() + "\n";
						break;
						
				case 1: result += "B: " + addTruck(this.map[i].isOccupied(), i) + 
							this.map[i].getCityCargo().toString() + "\n";
						break;
				case 2: result += "C: " + addTruck(this.map[i].isOccupied(), i) + 
						this.map[i].getCityCargo().toString() + "\n";
					break;
			
			}
			
		}
		
		
		
		return result;
	}
	
	/**
	 * Checks to see if the truck is at a city for the toString method, and if so will return a string
	 * @param occupied
	 * @param i
	 * @return
	 */
	private String addTruck(boolean occupied, int i) {
		if(this.map[i].isOccupied() == true){
			return "Truck ";
		}
		return "";
	}
	
	@Override
	public List<ActionStatePair> successor() {
		// TODO Auto-generated method stub
		return null;
	}

}
