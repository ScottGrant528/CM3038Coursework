package transportPuzzle;

import transportProblemData.*;

public class RunTransportPuzzle {
	//Main method to run the program
	public static void main(String[] args) {
		//initalising the setting class, settings can be changed in that class as needed.
		Settings setting = new Settings();
		
		/**
		 * Creating the map pieces
		 * 
		 */

		//Initialling the cities
		City A = new City(CityName.A, true);
		City B = new City(CityName.B, false);
		City C = new City(CityName.C, false);
		//Declaring the truck class
		Truck truck = new Truck(CityName.A);
		
		//Initialising the cargos
		Cargo C1 = new Cargo(CargoName.C1,2.5);
		Cargo C2 = new Cargo(CargoName.C2, 7.5);
		Cargo C3 = new Cargo(CargoName.C3, 3.0);
		Cargo C4 = new Cargo(CargoName.C4, 8.5);
		Cargo C5 = new Cargo(CargoName.C5, 10);
		Cargo C6 = new Cargo(CargoName.C6, 12);
		
		
		/**
		 * Initialising the initial and goal state classes
		 * 
		 */
		//Creating the initial state object
		TransportPuzzleState initState = new TransportPuzzleState();
		
		//Adding cargo
		//City A
		initState.map[0].addToCityCargo(C1);
		initState.map[0].addToCityCargo(C2);
		initState.map[0].addToCityCargo(C3);
		//City B
		initState.map[1].addToCityCargo(C4); 
		initState.map[1].addToCityCargo(C5);
		//City C
		initState.map[2].addToCityCargo(C6);
		//Creating the inital map string to Kit's coursework specifications
		String initalProblemStr = "===Problem===\n" + initState.toString();
		
		
		/**
		 * Creating the goal state of the problem
		 * 
		 */
		
		//Initialling the cities
		City Agoal = new City(CityName.A, true);
		City Bgoal = new City(CityName.B, false);
		City Cgoal = new City(CityName.C, false);
		// Declaring the truck class
		Truck truckGoal = new Truck(CityName.A);

		// Initialising the cargos
		Cargo C1goal = new Cargo(CargoName.C1, 2.5);
		Cargo C2goal = new Cargo(CargoName.C2, 7.5);
		Cargo C3goal = new Cargo(CargoName.C3, 3.0);
		Cargo C4goal = new Cargo(CargoName.C4, 8.5);
		Cargo C5goal = new Cargo(CargoName.C5, 10);
		Cargo C6goal = new Cargo(CargoName.C6, 12);
		//Creating the goal state object
		TransportPuzzleState goalState = new TransportPuzzleState(Agoal, Bgoal, Cgoal, truckGoal);
		
		//Adding Cargo 
		//City A
		goalState.map[0].addToCityCargo(C4goal);
		goalState.map[0].addToCityCargo(C6goal);
		//City B
		goalState.map[1].addToCityCargo(C1goal);
		goalState.map[1].addToCityCargo(C2goal);
		//City C
		goalState.map[2].addToCityCargo(C3goal);
		goalState.map[2].addToCityCargo(C5goal);
		
		//Testing the state class
		//System.out.println(goalState.toString());
		
		//Testing the Setting and State toString Methods
		//System.out.println(setting.toString() + "\n\n" + initalProblemStr + "\n->\n\n" + goalState.toString());
		
		
		/**
		 * Testing the Action method
		 */
		//Printing out initial state
		System.out.println("OLD STATE\n" + initState.toString());
		//Declaring Action method
		TransportPuzzleAction action = new TransportPuzzleAction(0,1,C3);
		//Testing Action toString
		System.out.println(action.toString());
		//Declaring the NewState object
		TransportPuzzleState newState = new TransportPuzzleState();
		//Applying the action
		newState = initState.applyAction(action);
		//printing the new state
		System.out.println("\nNEW STATE\n" + newState.toString());
		
		
		/**
		 * Checking equality and hashcode methods
		 */
		
		//Checking the equality method
		System.out.println("\nCHECKING EQUALITY FUNCTION\n Goal state to inital state:" + goalState.equals(initState) + 
			"\n Goal state to goal state: " + goalState.equals(goalState));
		
		//Checking the hashcode method 
		int initHash = initState.hashCode();
		int goalHash = goalState.hashCode();
		boolean equality = false;
		System.out.println("\nCHECKING HASHCODE FUNCTION\n Goal state to hashcode: " + goalHash +
				"\n Inital State to hashcode: " + initHash);
		
		//Checking to see if the hashcode values are different
		if(initHash == goalHash) {
			equality = true;
		}
		System.out.println(" It is '" + equality + "' that the goal and inital state hashes are equal.");
		
		//Re-initalising the variable
		equality = false;
		//Creating a copy of the goal state hashcode
		int goalHash2 = goalState.hashCode();
		//Comparing the goal state hash code with a copy of itself to ensure the equality method works
		if(goalHash2 == goalHash) {
			equality = true;
		}
		System.out.println(" It is '" + equality + "' that the goal and goal2 state hashes are equal.");
		
		
	}
	
	
}
