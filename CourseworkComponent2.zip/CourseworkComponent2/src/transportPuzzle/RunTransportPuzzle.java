package transportPuzzle;

import aips.search.Path;
import transportProblemData.*;

public class RunTransportPuzzle {
	//Main method to run the program
	public static void main(String[] args) {
		//initalising the setting class, settings can be changed in that class as needed.
		Settings setting = new Settings();
		
		/**
		 * Initialising the initial and goal state classes
		 * 
		 */
		
		/*
		 * INITIAL STATE
		 */
		//Initialling the cities
		City A = new City(CityName.A, true);
		City B = new City(CityName.B, false);
		City C = new City(CityName.C, false);
		//Declaring the truck class
		Truck truck = new Truck(CityName.A);
		
		//Initialising the cargos
		Cargo C1 = new Cargo(CargoName.C1,2.5);
		Cargo C2 = new Cargo(CargoName.C2, 7.5);
		Cargo C3 = new Cargo(CargoName.C3, 3.0);
		Cargo C4 = new Cargo(CargoName.C4, 8.5);
		Cargo C5 = new Cargo(CargoName.C5, 10);
		Cargo C6 = new Cargo(CargoName.C6, 12);
		
		
		
		//Creating the initial state object
		TransportPuzzleState initState = new TransportPuzzleState();
		//Adding cargo
		//City A
		initState.map[0].addToCityCargo(C1);
		initState.map[0].addToCityCargo(C2);
		initState.map[0].addToCityCargo(C3);
		//City B
		initState.map[1].addToCityCargo(C4); 
		initState.map[1].addToCityCargo(C5);
		//City C
		initState.map[2].addToCityCargo(C6);
		//Creating the inital map string to Kit's coursework specifications
		String initalProblemStr = "===Problem===\n" + initState.toString();
		//City cargo prints out fine
		//System.out.println(initState.map[0].getCityCargo());
		
		/*
		 * GOAL STATE
		 */
		//Initialling the cities
		City Agoal = new City(CityName.A, true);
		City Bgoal = new City(CityName.B, false);
		City Cgoal = new City(CityName.C, false);
		// Declaring the truck class
		Truck truckGoal = new Truck(CityName.A);

		// Initialising the cargos
		Cargo C1goal = new Cargo(CargoName.C1, 2.5);
		Cargo C2goal = new Cargo(CargoName.C2, 7.5);
		Cargo C3goal = new Cargo(CargoName.C3, 3.0);
		Cargo C4goal = new Cargo(CargoName.C4, 8.5);
		Cargo C5goal = new Cargo(CargoName.C5, 10);
		Cargo C6goal = new Cargo(CargoName.C6, 12);
		//Creating the goal state object
		TransportPuzzleState goalState = new TransportPuzzleState(Agoal, Bgoal, Cgoal, truckGoal);
		
		//Adding Cargo 
		//City A
		goalState.map[0].addToCityCargo(C4goal);
		goalState.map[0].addToCityCargo(C6goal);
		//City B
		goalState.map[1].addToCityCargo(C1goal);
		goalState.map[1].addToCityCargo(C2goal);
		//City C
		goalState.map[2].addToCityCargo(C3goal);
		goalState.map[2].addToCityCargo(C5goal);
		
		//System.out.println("goal state" + goalState.map[0].getCityCargo());
		
		/**
		 * 
		 * INITIAL SETTINGS OUTPUT
		 */
		
		//adding the current settings to the output
		System.out.println(setting.toString() + "\n");
		//adding the inital state of the problem
		System.out.println(initalProblemStr);
		//adding the goal state
		System.out.println("\n- >\n\n===Goal State===\n" + goalState.toString());
		//System.out.println("City a" + initState.map[0].getCityCargo());
		/**
		 * 
		 * SEARCHING FOR SOLUTIONS
		 * 
		 */
		//Creating the problem
		TransportPuzzleProblem problem = new TransportPuzzleProblem(initState, goalState);
		System.out.println("\nSearching...");
		Path path = problem.search();
		System.out.println("\nDone!");
		if(path==null) {
			System.out.println("\nNo Solution");
		} else { 
			path.print();
			System.out.println("Nodes visited: " + problem.nodeVisited);
			System.out.println("Cost: " + path.cost + "\n");
		}
		
		
		/**
		 * 
		 * PRINTING THE OUTPUT
		 */
		
		
		
		
	}
	
	
}
