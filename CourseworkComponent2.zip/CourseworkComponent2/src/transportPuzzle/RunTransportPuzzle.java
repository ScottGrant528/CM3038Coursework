package transportPuzzle;

import transportProblemData.*;

public class RunTransportPuzzle {
	public static void main(String[] args) {
		
		//Creating the initial state
		
		//Initialising the cities
		City A = new City(CityName.A, true);
		City B = new City(CityName.B, false);
		City C = new City(CityName.C, false);
		//Declaring the truck class
		Truck truck = new Truck(CityName.A);
		
		//Initialising the cargos
		Cargo C1 = new Cargo(CargoName.C1,2.5);
		Cargo C2 = new Cargo(CargoName.C2, 7.5);
		Cargo C3 = new Cargo(CargoName.C3, 3.0);
		Cargo C4 = new Cargo(CargoName.C4, 8.5);
		Cargo C5 = new Cargo(CargoName.C5, 10);
		Cargo C6 = new Cargo(CargoName.C6, 12);
		
		/*
		 * Creating the initial state of the problem
		 */
		//Creating a state class to save the initial state
		TransportPuzzleState state = new TransportPuzzleState(A, B, C, truck);
		
		//Adding cargo
		//City A
		state.map[0].addToCityCargo(C1); state.map[0].addToCityCargo(C2);state.map[0].addToCityCargo(C3);
		//City B
		state.map[1].addToCityCargo(C4); state.map[1].addToCityCargo(C5);
		//City C
		state.map[2].addToCityCargo(C6);
		System.out.println(state.toString());
		
		//state
		/*
		//Adding these to City A
		A.getCityCargo().add(C1);
		A.getCityCargo().add(C2);
		A.getCityCargo().add(C3);
		
		Cargo C4 = new Cargo(CargoName.C4, 8.5);
		Cargo C5 = new Cargo(CargoName.C5, 10);
		//Adding these to City B
		B.getCityCargo().add(C4);
		B.getCityCargo().add(C5);
		
		Cargo C6 = new Cargo(CargoName.C6, 12);
		//Add this cargo to City C
		C.getCityCargo().add(C6);
		
		//Create a state object to save all of this in
		//Then create a goal state object too 
		
		*/
		
		
	}
	
	
}
