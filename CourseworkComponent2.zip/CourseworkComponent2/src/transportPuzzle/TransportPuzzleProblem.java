package transportPuzzle;

import aips.search.*;
import aips.search.informed.*;
import transportProblemData.*;

public class TransportPuzzleProblem extends BestFirstSearchProblem{

	/**
	 * Construct a TransportPuzzleProblem object from the initial and goal state.
	 * @param initialState	The initial state.
	 * @param goalState		The goal state.
	 */
	
	public TransportPuzzleProblem(State initalState, State goalState) {
		super(initalState, goalState);
	}

	
	/**
	 * The evaluation function required by an informed search.
	 * @param node	The node to be evaluated.
	 * @return The score of the node. The lower the score, the more promising the node.
	 */
	@Override
	public double evaluation(Node node) {
		// TODO Auto-generated method stub
		return node.getCost() +  heuristic(node.state);
	}
	
	
	/**
	 * 
	 * @param currentState
	 * @return
	 */
	public double heuristic(State currentState) {
		//Initial value is 0.0
		double result = 0.0; 
		//Get the current state map array and cast into new object
		City map[] = ((TransportPuzzleState)currentState).map;
		//Get the goal state map array and cast into new object
		City goalMap[] = ((TransportPuzzleState)this.goalState).map;
		
		for(int i = 0; i < map.length; i++) {
			//get the initial and goal cities
			City city = map[i];
			City goalCity = goalMap[i];
			double truckWeight = ((TransportPuzzleState)currentState).truck.getTruckCargoWeight();
			
			//If the cargolists are not equal then add 1 to result
			if(!city.getCityCargo().equals(goalCity.getCityCargo())){
				//Calcualte the cost of travel given the total truck weight
				result += this.costOfTravel(city, goalCity, truckWeight);
			}//End of if statement
			
		}//End of For Loop
		return result;

	}//End of Method
	
	/**
	 * 
	 * Returns the cost of travel between to cities, given the truck weight.
	 * @param currCity
	 * @param nextCity
	 * @param weight
	 * @return
	 */
	private double costOfTravel(City currCity, City nextCity, double weight) {
		//store the cost of travel
		double travelCost = 0;
		//make a setting object to get the costs from 
		Settings setting = new Settings();
		
		//Costs of routes between cities
		if(currCity.getName() == CityName.A) {
			if(nextCity.getName() == CityName.B) {
				//Add the fixed cost plus the variable cost
				travelCost += setting.getCostAB() + (setting.getCostABperTon() * weight);
			} 
			else if(nextCity.getName() == CityName.C) {
				travelCost+= setting.getCostCA() + (setting.getCostCAperTon() * weight);
			} 
		} 
		else if(currCity.getName() == CityName.B){
			
			if(nextCity.getName() == CityName.A) {
				travelCost += setting.getCostAB() + (setting.getCostABperTon() * weight);
			}
			else if(nextCity.getName() == CityName.C) {
				travelCost += setting.getCostBC() + (setting.getCostBCperTon() * weight);
			}
		} 
		else if(currCity.getName() == CityName.C) {
			if(nextCity.getName() == CityName.A) {
				travelCost += setting.getCostCA() + (setting.getCostCAperTon() * weight);
			} 
			else if(nextCity.getName() == CityName.B) {
				travelCost += setting.getCostBC()  + (setting.getCostBCperTon() * weight);
			}
		} //End of if else statements
			
		
		return travelCost;
	}

	@Override
	public boolean isGoal(State currentState) {
		
		return false;
	}

	

}
