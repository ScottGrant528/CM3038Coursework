package transportPuzzle;

import aips.search.Node;
import aips.search.State;
import aips.search.informed.BestFirstSearchProblem;

public class TransportPuzzleProblem extends BestFirstSearchProblem{

	/**
	 * Construct a TransportPuzzleProblem object from the initial and goal state.
	 * @param initialState	The initial state.
	 * @param goalState		The goal state.
	 */
	
	public TransportPuzzleProblem(State initalState, State goalState) {
		super(initalState, goalState);
	}

	
	/**
	 * The evaluation function required by an informed search.
	 * @param node	The node to be evaluated.
	 * @return The score of the node. The lower the score, the more promising the node.
	 */
	@Override
	public double evaluation(Node node) {
		// TODO Auto-generated method stub
		return heuristic(node.state);
	}
	
	public double heuristic(State currentState) {
		return this.sumStraightLineDistance(currentState);
	}
	
	public double sumStraightLineDistance(State currentState){
		double result = 0.0;
		
		return result;
	}

	@Override
	public boolean isGoal(State currentState) {
		
		return false;
	}

	

}
