package transportPuzzle;

import aips.search.State;
import transportProblemData.*;

public class TransportAStarStraightLine  extends TransportGreedyStraightLine {
	
	public TransportAStarStraightLine() {
		/**
		 * Creates an empty state of the world
		 */
		City A = new City(CityName.A, false);
		City B = new City(CityName.B, false);
		City C = new City(CityName.C, false);
		
	}
	
	public TransportAStarStraightLine(State initalState, State goalState) {
		super(initalState, goalState);
	}

	

}
