package test;

public class TransportGreedy {

}
