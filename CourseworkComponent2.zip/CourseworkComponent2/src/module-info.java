module CourseworkComponent2 {
}